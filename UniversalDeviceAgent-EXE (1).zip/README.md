# Universal Device Agent - exe build

GitHub par upload karne ke baad: Actions tab -> workflow -> Run workflow.
Build ke baad file Actions run ke "Artifacts" section se download karein.
Optional: Settings -> Secrets and variables -> Actions -> Variables -> CONTROL_API_URL (https://...)
